-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2023 at 03:12 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `speedlinks`
--

-- --------------------------------------------------------

--
-- Table structure for table `default_google`
--

CREATE TABLE `default_google` (
  `id` int(11) NOT NULL,
  `role` varchar(500) NOT NULL DEFAULT 'default',
  `google_refresh_token` varchar(1000) NOT NULL,
  `google_access_token` varchar(1000) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE `records` (
  `id` int(11) NOT NULL,
  `record_name` varchar(500) NOT NULL,
  `google_refresh_token` varchar(1000) DEFAULT NULL,
  `sender_name` varchar(500) DEFAULT NULL,
  `sender_email` varchar(500) DEFAULT NULL,
  `description` varchar(5000) NOT NULL,
  `folder` varchar(500) NOT NULL,
  `file_type` varchar(500) DEFAULT NULL,
  `drive_email` varchar(500) NOT NULL,
  `record_id` varchar(500) NOT NULL,
  `user_id` varchar(500) NOT NULL,
  `file_name` varchar(500) DEFAULT NULL,
  `file_size` varchar(500) DEFAULT NULL,
  `file_id` varchar(500) DEFAULT NULL,
  `folder_id` varchar(500) DEFAULT NULL,
  `questions` longtext DEFAULT NULL,
  `answers` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(500) NOT NULL DEFAULT 'pending',
  `expiry_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`id`, `record_name`, `google_refresh_token`, `sender_name`, `sender_email`, `description`, `folder`, `file_type`, `drive_email`, `record_id`, `user_id`, `file_name`, `file_size`, `file_id`, `folder_id`, `questions`, `answers`, `created_at`, `updated_at`, `status`, `expiry_date`) VALUES
(88, 'TEST 1', '', NULL, NULL, 'trying this one for the first time', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', '9SHbhI08y', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-06 23:26:58', '2023-10-06 23:26:58', 'expired', NULL),
(89, 'TEST 1', '', NULL, NULL, 'trying this one for the first time', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'SsuBT6aVW', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-06 23:28:16', '2023-10-06 23:28:16', 'expired', NULL),
(90, 'TEST 1', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, 'trying this one for the first time', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'NMLvDEPll', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-06 23:35:35', '2023-10-06 23:35:35', 'expired', NULL),
(91, 'TEST 2', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, 'trying this one for the first time', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'DAwcetxC9', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-06 23:37:16', '2023-10-06 23:37:16', 'expired', NULL),
(92, 'TEST 3', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, 'trying this one for the first time', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'z8wmID9Jh', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-06 23:42:21', '2023-10-06 23:42:21', 'expired', '2023-10-08 00:42:21'),
(93, 'TEST 3', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, 'trying this one for the first time', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'VQS2KET8n', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-06 23:44:37', '2023-10-06 23:44:37', 'expired', '2023-10-08 00:44:37'),
(94, 'TEST 4', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, 'trying this one for the first time', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'p8cwAusnC', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-06 23:46:22', '2023-10-06 23:46:22', 'expired', '2023-10-08 00:46:22'),
(95, '', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, '', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'MaUPxCRK8', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-09 12:24:09', '2023-10-09 12:24:09', 'expired', '2023-10-10 13:24:09'),
(96, '', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, '', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'hzB9KXXaS', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-09 14:22:23', '2023-10-09 14:22:23', 'expired', '2023-10-10 15:22:23'),
(97, '345f2', '1//01wj-pNSm2d_LCgYIARAAGAESNwF-L9IrvL1n3H0sULH9ixeMQ_CXeicmtXNJtbs96eFm3tF68PV_7zl7POgPmV6Wsi19M5F19QM', NULL, NULL, '3344545v45 5454 45 45 45 454', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'beSlEfZ0c', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-10 19:25:06', '2023-10-10 19:25:06', 'expired', '2023-10-11 20:25:06'),
(98, 'jkjljj', '1//03VB3l3BHuOI_CgYIARAAGAMSNwF-L9IrPxrsHMl0kCfWvfxcmCLDMAO7jy7eGkBpxkZ5WONjfCCQrAgXtefcsMktHH_FH4GIaLk', NULL, NULL, ' mu louhas a red skirt', 'Speedlink', 'Speedlink', 'drrowly99@gmail.com', 'vWVEpCMLT', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-10 20:35:48', '2023-10-10 20:35:48', 'expired', '2023-10-11 21:35:48'),
(99, 'jkjljj', '1//03VB3l3BHuOI_CgYIARAAGAMSNwF-L9IrPxrsHMl0kCfWvfxcmCLDMAO7jy7eGkBpxkZ5WONjfCCQrAgXtefcsMktHH_FH4GIaLk', NULL, NULL, ' mu louhas a red skirt', '1tqbjt4kFwWnkRGN69nqToGUrFkVHjxsX', 'Speedlink', 'drrowly99@gmail.com', 'McJz7go9n', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-10 20:40:08', '2023-10-10 20:40:08', 'expired', '2023-10-11 21:40:08'),
(100, 'try today', '1//03VB3l3BHuOI_CgYIARAAGAMSNwF-L9IrPxrsHMl0kCfWvfxcmCLDMAO7jy7eGkBpxkZ5WONjfCCQrAgXtefcsMktHH_FH4GIaLk', NULL, NULL, 'upload this file', '1Q1Cr5dgbglJ8QRAvIW-5dojm4aV4TEnF', 'Speedlinks', 'drrowly99@gmail.com', '67cxXdPvt', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-11 11:48:51', '2023-10-11 11:48:51', 'expired', '2023-10-12 12:48:51'),
(101, 'try today', '1//03VB3l3BHuOI_CgYIARAAGAMSNwF-L9IrPxrsHMl0kCfWvfxcmCLDMAO7jy7eGkBpxkZ5WONjfCCQrAgXtefcsMktHH_FH4GIaLk', NULL, NULL, 'upload this file', '19TAlsf8Ez9fTrmTtFU6S0Cxp1DONr-pO', 'Speedlinks', 'drrowly99@gmail.com', 'z8d9i7bnt', 'hauyu7', NULL, NULL, NULL, NULL, NULL, NULL, '2023-10-11 11:48:52', '2023-10-11 11:48:52', 'expired', '2023-10-12 12:48:52'),
(102, 'my file', '1//01XdPtFEJrER2CgYIARAAGAESNwF-L9Irp6kKeQ1UdjL4hM_jfYST_893Gi8g3jqLd2JlpAru6lpC7Us4ohcaM5VagyONa0mzqCI', NULL, NULL, 'a file about my completion', 'divine', NULL, 'drrowly99@gmail.com', 'lv-EDzOMB', 'hauyu7', NULL, NULL, NULL, '1hcuOuH9Z1T7knBkRFa9DS-PZowcjdTDb', NULL, NULL, '2023-10-17 15:30:03', '2023-10-17 15:30:03', 'expired', '2023-10-18 16:30:03'),
(103, 'try 18th OCT', '1//01XdPtFEJrER2CgYIARAAGAESNwF-L9Irp6kKeQ1UdjL4hM_jfYST_893Gi8g3jqLd2JlpAru6lpC7Us4ohcaM5VagyONa0mzqCI', 'iso divine', 'iso@gmail.com', 'Testing for upload to folder', 'Speed', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'drrowly99@gmail.com', 'vufisKyw0', 'hauyu7', 'FUNDING REQUIREMENTS.docx', '14715', '1ETEedGOeg4LIFbkcVPzOIYcvCfTwCm4K', '1G5ogZoIWs37qbCrixtZEocKMm1E0F7Mj', 'what is your name, how old are you, when were you born', 'mmm, mmm, mmm', '2023-10-18 14:58:15', '2023-10-18 14:58:15', 'completed', '2023-10-30 15:58:15'),
(104, 'try 18th OCT', '1//01XdPtFEJrER2CgYIARAAGAESNwF-L9Irp6kKeQ1UdjL4hM_jfYST_893Gi8g3jqLd2JlpAru6lpC7Us4ohcaM5VagyONa0mzqCI', NULL, NULL, 'Testing for upload to folder', 'divine', NULL, 'drrowly99@gmail.com', 'RXuS1jPcu', 'hauyu7', NULL, NULL, NULL, '1hcuOuH9Z1T7knBkRFa9DS-PZowcjdTDb', NULL, NULL, '2023-10-18 15:53:42', '2023-10-18 15:53:42', 'expired', '2023-10-19 16:53:42'),
(105, 'nanami', '1//03CoKDoJ0EuJ0CgYIARAAGAMSNwF-L9Irz82aqOkATFLuwf6u-IbjT_7TxiSFMUaJyweTz7xderke0GhW1W3OeVNu1F4BbRUtblQ', NULL, NULL, 'my good friend', 'Speedlink', NULL, 'drrowly99@gmail.com', 'LF50391XS', '8602b42d-5595-49f8-87d5-c1db18ed8ced', NULL, NULL, NULL, '1tqbjt4kFwWnkRGN69nqToGUrFkVHjxsX', NULL, NULL, '2023-11-01 16:22:40', '2023-11-01 16:22:40', 'expired', '2023-11-02 17:22:40'),
(106, 'nameless', '1//03_nPc-aRscZtCgYIARAAGAMSNwF-L9IrR3oLFOvj51VECIFokK0ByzjnLoRVz0v_jVJSehtvKQ8ImaGfghtm0WWlAdu2cihJxfU', 'iso divine', 'iso@gmail.com', 'this is a test of width', 'Resume', 'image/jpeg', 'drrowly99@gmail.com', 'c6Tsf2all', '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'pexels-julia-m-cameron-4144099.jpg', '5814983', '1TpGemszz3OYu8Nee_DwBPjAKaL_Fymun', '1rHiUULmZdP2DZRu2IBEIPoPvagOuST31', 'what is your name-required, how old are you-required', 'mmm, mmm', '2023-11-01 21:22:52', '2023-11-01 21:22:52', 'completed', '2023-11-02 22:22:52'),
(107, 'Take it or leave it', '1//03CUPnyvzdCTTCgYIARAAGAMSNwF-L9IrUUXd81dvC6mH7Rual_vHx-zfEcAXUhAp6kbRZAktB41CaxDKupj1gfsuXq2JFOFAx_M', NULL, NULL, 'make me a man after God\'s own heart', 'Speed', NULL, 'drrowly99@gmail.com', '5XKExcTEM', '8602b42d-5595-49f8-87d5-c1db18ed8ced', NULL, NULL, NULL, '1G5ogZoIWs37qbCrixtZEocKMm1E0F7Mj', 'Why are you Sad-Required, What is the name of your secondary school-Required, Finally, your name-Not Required', NULL, '2023-11-02 16:53:12', '2023-11-02 16:53:12', 'expired', '2023-11-03 17:53:12'),
(108, 'Take it or leave it', '1//03CUPnyvzdCTTCgYIARAAGAMSNwF-L9IrUUXd81dvC6mH7Rual_vHx-zfEcAXUhAp6kbRZAktB41CaxDKupj1gfsuXq2JFOFAx_M', NULL, NULL, 'make me a man after God\'s own heart', 'Speed', NULL, 'drrowly99@gmail.com', 'R3XOT2ai3', '8602b42d-5595-49f8-87d5-c1db18ed8ced', NULL, NULL, NULL, '1G5ogZoIWs37qbCrixtZEocKMm1E0F7Mj', 'Why are you Sad-Required, What is the name of your secondary school-Required, Finally, your name-Not Required', NULL, '2023-11-02 16:53:32', '2023-11-02 16:53:32', 'expired', '2023-11-03 17:53:32'),
(109, 'HOME', '1//03CUPnyvzdCTTCgYIARAAGAMSNwF-L9IrUUXd81dvC6mH7Rual_vHx-zfEcAXUhAp6kbRZAktB41CaxDKupj1gfsuXq2JFOFAx_M', 'iso divine', 'iso@gmail.com', 'home of the lining', 'TEST', 'image/jpeg', 'drrowly99@gmail.com', 'Mt3a42lpM', '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'pexels-vladimir-srajber-13963756.jpg', '4630952', '1ANP9kCsaYAR8gWA3SJhJh2k1R26dLuEU', '1935shITFUii9nYtpdiqP72UvZSTrw-R8', 'Whats your age-Required, What school did you graduate from-Required, How much salary do you expect-Not Required', '27, uniport, 500000', '2023-11-02 16:56:13', '2023-11-02 16:56:13', 'completed', '2023-11-03 17:56:13'),
(110, 'Test Uploader 1', '1//09V_62N-r61p1CgYIARAAGAkSNwF-L9IreyWKNnaVuqSwTxC19CNwpdvZhCpI39Ii7-PPcsuzHPzcHy_kypPSii8ItKJQiYAHsdw', 'iso divine', 'iso@gmail.com', 'Trying out a new uploader', 'Speed', 'image/jpeg', 'drrowly99@gmail.com', 'XvNsekq5e', '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'pexels-sora-shimazaki-5668872.jpg', '5136554', '1ivgoyz285_fmO97H17RTe1yCWLpMh-Qu', '1G5ogZoIWs37qbCrixtZEocKMm1E0F7Mj', 'How old are you-Required, What is your Maiden Name-Not Required', '28, Lizy', '2023-11-02 18:22:37', '2023-11-02 18:22:37', 'completed', '2023-11-03 19:22:37');

-- --------------------------------------------------------

--
-- Table structure for table `revoked_token`
--

CREATE TABLE `revoked_token` (
  `id` int(11) NOT NULL,
  `token` varchar(5000) NOT NULL,
  `jit` varchar(5000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `user_id` varchar(500) NOT NULL,
  `record_id` varchar(500) NOT NULL,
  `ask_name` varchar(500) NOT NULL,
  `send_notification` varchar(500) NOT NULL,
  `quantity` varchar(500) NOT NULL,
  `file_type` varchar(500) NOT NULL,
  `custom_type` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `upload_size` varchar(500) NOT NULL,
  `custom_size` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `user_id`, `record_id`, `ask_name`, `send_notification`, `quantity`, `file_type`, `custom_type`, `upload_size`, `custom_size`, `created_at`) VALUES
(1, 'hauyu7', 'ffvBVHkEY', 'true', 'true', 'multiple_files', 'any_exe', NULL, 'any_size', '', '2023-10-01 07:55:02'),
(2, 'hauyu7', 'iYfQPHBoQ', 'true', 'true', 'multiple_files', 'any_exe', NULL, 'any_size', '', '2023-10-01 07:55:02'),
(3, 'hauyu7', '92yiQgPoL', 'true', 'true', 'multiple_files', 'custom_exe', NULL, 'any_size', '', '2023-10-01 08:53:45'),
(4, 'hauyu7', '60F1ImHgl', 'true', 'true', 'multiple_files', 'document_exe', NULL, 'any_size', '', '2023-10-01 08:55:00'),
(5, 'hauyu7', 'KhJ_1qeF_', 'true', 'true', 'multiple_files', 'custom_exe', 'mono,tag', 'any_size', '', '2023-10-01 09:15:46'),
(6, 'hauyu7', 'hOKEkaUQy', 'true', 'true', 'multiple_files', 'custom_exe', 'jpg,pdf', 'any_size', NULL, '2023-10-01 21:56:44'),
(7, 'hauyu7', 'SrXnwHEPt', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-02 12:11:55'),
(8, 'hauyu7', 'xsZY031f8', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-06 23:54:49'),
(9, 'hauyu7', 'NMvaa4b1w', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-06 23:56:30'),
(10, 'hauyu7', '9JgqgHl-Y', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-06 23:59:27'),
(11, 'hauyu7', '2jdi7BYjY', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-06 23:59:42'),
(12, 'hauyu7', 'keS2w0YsI', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:01:55'),
(13, 'hauyu7', '9tznLoYji', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:02:10'),
(14, 'hauyu7', '9SHbhI08y', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:26:58'),
(15, 'hauyu7', 'SsuBT6aVW', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:28:16'),
(16, 'hauyu7', 'NMLvDEPll', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:35:35'),
(17, 'hauyu7', 'DAwcetxC9', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:37:16'),
(18, 'hauyu7', 'z8wmID9Jh', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:42:21'),
(19, 'hauyu7', 'VQS2KET8n', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:44:37'),
(20, 'hauyu7', 'p8cwAusnC', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-07 00:46:22'),
(21, 'hauyu7', 'MaUPxCRK8', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-09 13:24:09'),
(22, 'hauyu7', 'hzB9KXXaS', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-09 15:22:23'),
(23, 'hauyu7', 'beSlEfZ0c', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-10 20:25:06'),
(24, 'hauyu7', 'vWVEpCMLT', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-10 21:35:48'),
(25, 'hauyu7', 'McJz7go9n', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-10 21:40:08'),
(26, 'hauyu7', '67cxXdPvt', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-11 12:48:51'),
(27, 'hauyu7', 'z8d9i7bnt', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-11 12:48:52'),
(28, 'hauyu7', 'lv-EDzOMB', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-17 16:30:03'),
(29, 'hauyu7', 'vufisKyw0', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-18 15:58:15'),
(30, 'hauyu7', 'RXuS1jPcu', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-10-18 16:53:42'),
(31, '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'LF50391XS', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-11-01 17:22:40'),
(32, '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'c6Tsf2all', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-11-01 22:22:52'),
(33, '8602b42d-5595-49f8-87d5-c1db18ed8ced', '5XKExcTEM', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-11-02 17:53:12'),
(34, '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'R3XOT2ai3', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-11-02 17:53:32'),
(35, '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'Mt3a42lpM', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-11-02 17:56:13'),
(36, '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'XvNsekq5e', 'true', 'true', 'multiple_files', 'any_exe', '', 'any_size', NULL, '2023-11-02 19:22:37');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `user_id` varchar(500) NOT NULL,
  `plan` int(11) NOT NULL,
  `payment_id` varchar(500) NOT NULL,
  `payment_reference` varchar(500) NOT NULL,
  `amount` int(11) UNSIGNED NOT NULL,
  `fee` double(11,2) NOT NULL,
  `status` varchar(500) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `number` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `goog_refresh_token` varchar(255) DEFAULT NULL COMMENT 'this is a row for google oath2 refresh token',
  `access_token` varchar(1000) DEFAULT NULL COMMENT 'Users login access token',
  `plan` int(11) DEFAULT 1 COMMENT 'Users selected plan',
  `status` varchar(255) DEFAULT NULL COMMENT 'Check the useres status, depending on clients choice it will have different numbers or texts',
  `session_uri` varchar(1000) DEFAULT NULL COMMENT 'Users session uri for uploading data to google drive',
  `count_uploads` int(11) DEFAULT 0 COMMENT 'counting how many times user has made an upload',
  `bytes _total` varchar(255) DEFAULT NULL COMMENT 'total bytes a user has uploaded',
  `user_id` varchar(255) DEFAULT NULL COMMENT 'the user id',
  `role` varchar(500) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `email`, `password`, `number`, `created_at`, `goog_refresh_token`, `access_token`, `plan`, `status`, `session_uri`, `count_uploads`, `bytes _total`, `user_id`, `role`) VALUES
(1, 'didi', 'mercy', 'iso@gmail.com', '$2b$10$7OaiLuZHBYfz9F9bdveS7u9JxeJlCgOw0gVm83XGPVenAAgYhVs6q', '09079417401', '2023-10-31 13:42:39', NULL, NULL, 1, 'Active', NULL, 0, NULL, '8602b42d-5595-49f8-87d5-c1db18ed8ced', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_google`
--

CREATE TABLE `user_google` (
  `id` int(11) NOT NULL,
  `user_id` varchar(500) NOT NULL,
  `refresh_token` varchar(1000) NOT NULL,
  `access_token` varchar(1000) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp(),
  `email` varchar(500) NOT NULL,
  `storage_email` varchar(500) DEFAULT NULL,
  `role` varchar(300) NOT NULL,
  `id_token` varchar(2000) DEFAULT NULL,
  `expiry_date` varchar(500) NOT NULL,
  `expire_next` datetime DEFAULT NULL,
  `token_type` varchar(255) DEFAULT NULL,
  `scope` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_google`
--

INSERT INTO `user_google` (`id`, `user_id`, `refresh_token`, `access_token`, `date_created`, `date_updated`, `email`, `storage_email`, `role`, `id_token`, `expiry_date`, `expire_next`, `token_type`, `scope`) VALUES
(11, 'hauyu7', '1//01XdPtFEJrER2CgYIARAAGAESNwF-L9Irp6kKeQ1UdjL4hM_jfYST_893Gi8g3jqLd2JlpAru6lpC7Us4ohcaM5VagyONa0mzqCI', 'ya29.a0AfB_byBKgRDo2FREzJTlJI0FYhQswFluAHSAJAapngl7b6sjiHJXT3mhs0xfXiwUG3inUkweanbTEVNE6_iLSDRFwLnedlCJBXm0nbAa_J2GU3SGTxeqF1HGGsMmp7d0vW0tZXTH-82ae_bXnnxD6Gny6TPujwpI1249IgaCgYKAaMSARISFQGOcNnCbrl9q9aBhYVfYNR6NFgDCg0173', '2023-10-07 00:25:14', '2023-10-07 00:25:14', 'drrowly@gmil.com', 'isodivine150@gmail.com', 'default', 'eyJhbGciOiJSUzI1NiIsImtpZCI6ImM2MjYzZDA5NzQ1YjUwMzJlNTdmYTZlMWQwNDFiNzdhNTQwNjZkYmQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI3NDUwMDcyNzg0OC1kZjhyczg4dGlwNTFpdWM1M2hvODc1b2VwOXM3a2NkYi5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsImF1ZCI6Ijc0NTAwNzI3ODQ4LWRmOHJzODh0aXA1MWl1YzUzaG84NzVvZXA5czdrY2RiLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTA4Njk2MTIwNjgxODUwMTY2MjU4IiwiZW1haWwiOiJpc29kaXZpbmUxNTBAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJhOU92enpKa3prVlh4ZVpXc0RjaWVBIiwibmFtZSI6IkRpdmluZSBpc28iLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jTDhab2ZiQkxLaDhBN1VmWTJPZTFUN3Ryc1VpSTN5Sm9YaEx4VE9xb1d5PXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IkRpdmluZSIsImZhbWlseV9uYW1lIjoiaXNvIiwibG9jYWxlIjoiZW4iLCJpYXQiOjE2OTY2MzQ3MTMsImV4cCI6MTY5NjYzODMxM30.QpPpMwXuanWVDf_mPNRDCAgzfPLIhv65N0yERy2CM-gbwkvpMcfNUOe165QZR82uhekky4ulHYWu5ItVdp_jVI8-tQr44kfjRzzHK0u2ARbIX_b0EXjb8vrYOAacIhHpuNWVGY1FD271t0vZmfdDAdsjNNcz8mB5F8uSzwYwOXGyfe_kUVYN4bSgqjDCY9QYEJ9LolTNA4N2NM4S0kQCBfUYDz6QHmI121c9JoDtp4SRFLCu-BRLTPkWIe1VDjGyaShR46vOh3aajAd61_43_5JUpKwf-NamqCZvaAaW6vHGmnVfbWv00y79lCUz9uiX2IlYX0tyecQp--a07ynejQ', '1697644655286', '2023-10-08 00:25:14', 'Bearer', 'https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/drive openid'),
(12, '8602b42d-5595-49f8-87d5-c1db18ed8ced', '1//09V_62N-r61p1CgYIARAAGAkSNwF-L9IreyWKNnaVuqSwTxC19CNwpdvZhCpI39Ii7-PPcsuzHPzcHy_kypPSii8ItKJQiYAHsdw', 'ya29.a0AfB_byD8ShSCHMOLIczyEtTjpeoTfJEnkWCI8vYCuysXajVX630FjnkzrqQik1I6-D9q9Q7jeyfwtCU_c-mg_05A4je7fBesrrKvwvw5thGFBl1JgP2PhnyC_3zcGLxsjx4TWSM1-yjjWk-gdpitMkAWR1UJXkmv-Y82aCgYKAWcSARISFQGOcNnCJvcMCpsmjpDA9M83X3YQlQ0171', '2023-11-01 17:07:24', '2023-11-01 17:07:24', 'iso@gmail.com', 'isodivine150@gmail.com', 'user', 'eyJhbGciOiJSUzI1NiIsImtpZCI6ImY1ZjRiZjQ2ZTUyYjMxZDliNjI0OWY3MzA5YWQwMzM4NDAwNjgwY2QiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI3NDUwMDcyNzg0OC1kZjhyczg4dGlwNTFpdWM1M2hvODc1b2VwOXM3a2NkYi5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsImF1ZCI6Ijc0NTAwNzI3ODQ4LWRmOHJzODh0aXA1MWl1YzUzaG84NzVvZXA5czdrY2RiLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTA4Njk2MTIwNjgxODUwMTY2MjU4IiwiZW1haWwiOiJpc29kaXZpbmUxNTBAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJCTnNGRVZGRmRjNzdTdkd4ODkzQzB3IiwibmFtZSI6IkRpdmluZSBpc28iLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jTDhab2ZiQkxLaDhBN1VmWTJPZTFUN3Ryc1VpSTN5Sm9YaEx4VE9xb1d5PXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IkRpdmluZSIsImZhbWlseV9uYW1lIjoiaXNvIiwibG9jYWxlIjoiZW4iLCJpYXQiOjE2OTg4NTQ4NDAsImV4cCI6MTY5ODg1ODQ0MH0.OwdMykeGqAxTazsHqs3KlhJaFrqYH1e9LYYB93tY0uFJOWKCxY4iT1lD7o-zjwqbfVfp3_Ea3-XDmwdUcm6Au-xZaInytn1_3woeJy9CnBSjaMpQujSyVAu1SK6kL1LDfkuELX4h59tmuyPrkgLmMRvwbbVpCSVq_ldMmwnfW2MkN0VVKrQsGqfEPtBQx0oBiOB8T9onhlFy6P_aK7C4pXYrSlDuUsQc0uTD0oja-h0lhDfJjN35DPAJR0-Mp2Z3ZESGrTHfDVelLUefJX0LnjMyJT2lOCSzIr4naOdJ8rKateIBSpjoL-yf29_6MjpyrjW82nWZnOsTynyS-N_TDg', '1698952660904', '2023-11-02 17:07:24', 'Bearer', 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/userinfo.profile openid');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `default_google`
--
ALTER TABLE `default_google`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `record_id` (`record_id`,`user_id`,`file_id`,`folder_id`);

--
-- Indexes for table `revoked_token`
--
ALTER TABLE `revoked_token`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`) USING HASH;

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`,`number`,`user_id`);

--
-- Indexes for table `user_google`
--
ALTER TABLE `user_google`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `default_google`
--
ALTER TABLE `default_google`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `records`
--
ALTER TABLE `records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `revoked_token`
--
ALTER TABLE `revoked_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_google`
--
ALTER TABLE `user_google`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
