// generateId.mjs
import { nanoid } from 'nanoid';

export function generateUniqueID() {
  return nanoid();
}
